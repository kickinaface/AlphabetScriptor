Alphabet Scriptor Desktop v1.5.3

You must have NodeJS installed to build the application.

$ sudo npm install
$ electron-packager ./ "Alphabet Scriptor" --icon=./MyIcon.icns

Install the packages first for electron packager, then run the command to build the application.

-Christopher W Carter
11/4/2024
